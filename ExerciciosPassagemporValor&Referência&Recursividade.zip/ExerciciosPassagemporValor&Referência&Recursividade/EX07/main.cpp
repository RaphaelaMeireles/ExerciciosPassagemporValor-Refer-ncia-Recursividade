#include <iostream>

using namespace std;

int recursivamente(int posicao) {
    if (posicao <= 1) {
        return posicao;
    }
    return recursivamente(posicao - 1) + recursivamente(posicao - 2);
}

int iterativamente(int posicao) {
    if (posicao <= 1) {
        return posicao;
    }

    int a = 0, b = 1, c;
    for (int i = 2; i <= posicao; ++i) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

int main() {
    int posicao;

    cout << "Qual posicao voce deseja?" << endl;
    cin >> posicao;

    while(posicao < 0) {
        cout << "ERRO!! o valor deve ser maior ou igual a 0: " << endl;
        cin >> posicao;
    }

    cout << "((Recursivo)) O valor da sequencia nessa determinada posicao eh:" << endl;
    int resultadoR = recursivamente(posicao);
    cout << resultadoR << endl;

    cout << "((Iterativo)) O valor da sequencia nessa determinada posicao eh:" << endl;
    int resultadoI = iterativamente(posicao);
    cout << resultadoI << endl;

    system("pause");
    return 0;
}
