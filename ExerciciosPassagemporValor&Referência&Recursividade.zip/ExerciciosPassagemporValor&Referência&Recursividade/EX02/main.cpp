#include <iostream>

using namespace std;

void MinutosEmHora(int minP, int &hora, int &min) {
    hora = minP / 60;
    min = minP % 60;
}

int main() {
    int minP, min, hora;

    cout << "Digite o total de minutos passados ao longo do dia: " << endl;
    cin >> minP;

    MinutosEmHora(minP, hora, min);

    cout << hora << " horas e " << min << " minutos. " << endl;

    return 0;
}
