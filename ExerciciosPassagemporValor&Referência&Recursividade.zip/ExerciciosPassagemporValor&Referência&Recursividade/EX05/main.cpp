#include <iostream>

using namespace std;

int pesquisaBinaria(int vetor[], int tamanho, int valores) {
    int inicio = 0;
    int fim = tamanho - 1;
    int meio;

    while (inicio <= fim) {
        meio = inicio + (fim - inicio) / 2;

        if (vetor[meio] == valores) {
            return meio;
        }
        if (vetor[meio] < valores) {
            inicio = meio + 1;
        }
        else {
            fim = meio - 1;
        }
    }

    return -1;
}

int main() {
    int vetor[] = {0, 18, 22, 25, 34, 40, 51, 66, 75, 87};
    int tamanho = 10;
    int valores[] = {75, 22, 90};

    for(int i = 0; i < 3; i++) {
        int resultado = pesquisaBinaria(vetor, tamanho, valores[i]);

        if (resultado != -1) {
            cout << "O valor " << valores[i] << " foi encontrado. Indice [" << resultado << "] " << endl;
        }
        else {
            cout << "O valor " << valores[i] << " nao foi encontrado." << endl;
        }
    }

    system("pause");
    return 0;
}
