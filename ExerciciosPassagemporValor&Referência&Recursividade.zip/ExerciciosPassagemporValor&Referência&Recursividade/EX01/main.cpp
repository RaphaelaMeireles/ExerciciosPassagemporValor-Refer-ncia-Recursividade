#include <iostream>

using namespace std;
//Faça uma função que recebe a idade de uma pessoa em dias e retorna essa idade expressa em anos, meses e dias.

int conversao(int idadedias) {
    int anos, meses, dias;
    anos = idadedias/360;
    dias = idadedias%360;
    meses = dias/30;
    dias = dias%30;

    cout << "anos: " << anos <<"\n" << "meses: " << meses <<"\n" << "dias: " << dias <<"\n";

    return anos, meses, dias;
}


int main() {

    int idadedias;

    cout << "Digite sua idade em dias: " << endl;
    cin >> idadedias;

    conversao(idadedias);

    system("pause");
    return 0;
}
