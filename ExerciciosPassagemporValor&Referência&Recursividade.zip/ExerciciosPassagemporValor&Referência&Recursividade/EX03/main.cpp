#include <iostream>

using namespace std;

//Faça uma função que receba por parâmetro o tempo de duração expressa em segundos e
//retorna também por parâmetro esse tempo em horas, minutos e  segundos.

int conversaoTempo(int segTotais, int &duracaoHoras, int &duracaoMin, int &duracaoSeg){

    duracaoHoras = segTotais/3600;
    segTotais = segTotais%3600;
    duracaoMin = segTotais/60;
    duracaoSeg = segTotais%60;

    return segTotais, duracaoHoras, duracaoMin, duracaoSeg;
}

int main() {
    int duracaoHoras, duracaoMin, duracaoSeg;
    int segTotais = 0;

    cout << "Digite o tempo de duracao em segundos: " << endl;
    cin >> segTotais;

    conversaoTempo(segTotais, duracaoHoras, duracaoMin, duracaoSeg);

    cout << "Este eh o tempo de duracao em: \n" << "Horas >> " << duracaoHoras << "\nMinutos >> " << duracaoMin << "\nSegundos >> " << duracaoSeg << endl;

    system("pause");
    return 0;
}
