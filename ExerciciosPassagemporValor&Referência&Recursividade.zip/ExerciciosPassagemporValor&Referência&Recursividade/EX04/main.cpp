
#include <iostream>
#include <cmath>

using namespace std;

void lerValoresdaMatriz(int matriz[20][25], int M, int N) {
    cout << "Digite o valor dos elemtentos da matriz: " << endl;
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << "Posicao [" << i << "][" << j << "]: ";
            cin >> matriz[i][j];
        }
    }
}

void calcularMatrizTransposta(int matriz[20][25], int matrizTransposta[20][25], int M, int N) {
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            matrizTransposta[j][i] = matriz[i][j];
        }
    }
}

void multiplicaMatriz(int matriz[20][25], int resultado[20][25], int M, int N, int K) {
    for(int i = 0; i < M; i ++) {
        for(int j = 0; j < N; j++) {
            resultado[i][j] = matriz[i][j] * K;
        }
    }
}

void somarMatrizes(int matriz[20][25], int matriz2[20][25], int resultado[20][25], int M, int N) {
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            resultado[i][j] = matriz[i][j] + matriz2[i][j];
        }
    }
}

void imprimirResultadosMatriz(int matriz[20][25], int M, int N) {
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << "[" << matriz[i][j] << "] ";
        }
        cout << endl;
    }
}

int main() {

    int matriz[20][25], matriz2[20][25], matrizTransposta[20][25], matrizMultiplicada[20][25], somaMatriz[20][25];
    int M, N, K;

    cout << "Digite as dimencoes da matriz 1 (M <= 20 X N <= 25): " << endl;
    cin >> M >> N;

    while (M > 20 || N > 25) {
        cout << "Dimensoes invalidas!" << endl;
        cout << "Digite novamente: " << endl;
        cin >> M >> N;
    }

    lerValoresdaMatriz(matriz, M, N);

    calcularMatrizTransposta(matriz, matrizTransposta, M, N);

    cout << "Digite o valor ' K ' para multiplicar: " << endl;
    cin >> K;

    multiplicaMatriz(matriz, matrizMultiplicada, M, N, K);

    cout << "Segunda Matriz. " << endl;
    lerValoresdaMatriz(matriz2, M, N);

    somarMatrizes(matriz, matriz2, somaMatriz, M, N);

    cout << "Matriz transposta: " << endl;
    imprimirResultadosMatriz(matrizTransposta, N, M);

    cout << "Matriz multiplicada pelo valor de K. K = " << K << ":" << endl;
    imprimirResultadosMatriz(matrizMultiplicada, M, N);

    cout << " Matrizes somadas: " << endl;
    imprimirResultadosMatriz(somaMatriz, M, N);

    return 0;
}
