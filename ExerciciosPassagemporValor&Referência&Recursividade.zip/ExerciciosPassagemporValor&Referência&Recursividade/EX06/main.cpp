
#include <iostream>

using namespace std;

int recursivamente(int valorN) {

    if (valorN == 1) {
        return 1;
    }
    return valorN + recursivamente(valorN - 1);

}

int iterativamente(int valorN, int soma) {

    for (int i = 1; i <= valorN; ++i) {
        soma+= i;
    }

    return soma;
}

int main() {

    int valorN, soma = 0;

    cout << "Digite um valor: " << endl;
    cin >> valorN;

    while(valorN <=0) {
        cout << "ERRO!! o valor deve ser maior que 0: " << endl;
        cin >> valorN;
    }

    cout << "Recursivo:" << endl;
    int resultadoR = recursivamente(valorN);
    cout << resultadoR << endl;

    cout << "Iterativo:" << endl;
    int resultadoI = iterativamente(valorN, soma);
    cout << resultadoI << endl;

    return 0;
}